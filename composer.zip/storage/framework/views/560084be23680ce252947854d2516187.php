<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'description', 'image' => null, 'link' => null, 'date' => null, 'author' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'description', 'image' => null, 'link' => null, 'date' => null, 'author' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="bg-white rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100 overflow-hidden">
    <?php if($image): ?>
        <div class="h-48 bg-gray-200 overflow-hidden">
            <img src="<?php echo e($image); ?>" alt="<?php echo e($title); ?>" class="w-full h-full object-cover">
        </div>
    <?php endif; ?>
    <div class="p-6">
        <?php if($date || $author): ?>
            <div class="flex items-center text-sm text-gray-500 mb-3">
                <?php if($date): ?>
                    <span><?php echo e($date); ?></span>
                <?php endif; ?>
                <?php if($date && $author): ?>
                    <span class="mx-2">•</span>
                <?php endif; ?>
                <?php if($author): ?>
                    <span>By <?php echo e($author); ?></span>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <h3 class="text-xl font-bold text-gray-900 mb-3 line-clamp-2">
            <?php if($link): ?>
                <a href="<?php echo e($link); ?>" class="hover:text-indigo-600 transition-colors duration-200">
                    <?php echo e($title); ?>

                </a>
            <?php else: ?>
                <?php echo e($title); ?>

            <?php endif; ?>
        </h3>
        
        <?php if($description): ?>
            <p class="text-gray-600 mb-4 line-clamp-3">
                <?php echo e($description); ?>

            </p>
        <?php endif; ?>
        
        <?php if($link): ?>
            <a href="<?php echo e($link); ?>" class="inline-flex items-center text-indigo-600 font-medium hover:text-indigo-700 transition-colors duration-200">
                Read more
                <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                </svg>
            </a>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\projects\streetversity\resources\views/components/card.blade.php ENDPATH**/ ?>