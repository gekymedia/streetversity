@extends('layouts.app')

@section('content')
<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 text-gray-900">
                <h1 class="text-2xl font-bold mb-4">Welcome to Your Dashboard!</h1>
                <p class="mb-4">{{ __("You're logged in!") }}</p>
                
                @if(auth()->user()->hasRole('admin'))
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                        <h2 class="text-lg font-semibold text-blue-800 mb-2">Admin Access</h2>
                        <p class="text-blue-700 mb-2">You have administrator privileges.</p>
                        <a href="{{ route('admin.dashboard') }}" class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 focus:bg-blue-700 active:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition ease-in-out duration-150">
                            Go to Admin Panel
                        </a>
                    </div>
                @endif

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <h3 class="font-semibold text-lg mb-2">Quick Actions</h3>
                        <ul class="space-y-2">
                            <li>
                                <a href="{{ route('profile.edit') }}" class="text-blue-600 hover:text-blue-800">
                                    Update Profile
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('blog.index') }}" class="text-blue-600 hover:text-blue-800">
                                    View Blog
                                </a>
                            </li>
                            <li>
                                <a href="{{ route('contact') }}" class="text-blue-600 hover:text-blue-800">
                                    Contact Us
                                </a>
                            </li>
                        </ul>
                    </div>

                    <div class="bg-gray-50 p-4 rounded-lg">
                        <h3 class="font-semibold text-lg mb-2">Account Info</h3>
                        <div class="space-y-2">
                            <p><strong>Name:</strong> {{ auth()->user()->name }}</p>
                            <p><strong>Email:</strong> {{ auth()->user()->email }}</p>
                            <p><strong>Role:</strong> 
                                @foreach(auth()->user()->getRoleNames() as $role)
                                    <span class="inline-block bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">{{ ucfirst($role) }}</span>
                                @endforeach
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection