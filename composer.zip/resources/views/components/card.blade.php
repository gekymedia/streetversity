@props(['title', 'description', 'image' => null, 'link' => null, 'date' => null, 'author' => null])

<div class="bg-white rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100 overflow-hidden">
    @if($image)
        <div class="h-48 bg-gray-200 overflow-hidden">
            <img src="{{ $image }}" alt="{{ $title }}" class="w-full h-full object-cover">
        </div>
    @endif
    <div class="p-6">
        @if($date || $author)
            <div class="flex items-center text-sm text-gray-500 mb-3">
                @if($date)
                    <span>{{ $date }}</span>
                @endif
                @if($date && $author)
                    <span class="mx-2">•</span>
                @endif
                @if($author)
                    <span>By {{ $author }}</span>
                @endif
            </div>
        @endif
        
        <h3 class="text-xl font-bold text-gray-900 mb-3 line-clamp-2">
            @if($link)
                <a href="{{ $link }}" class="hover:text-indigo-600 transition-colors duration-200">
                    {{ $title }}
                </a>
            @else
                {{ $title }}
            @endif
        </h3>
        
        @if($description)
            <p class="text-gray-600 mb-4 line-clamp-3">
                {{ $description }}
            </p>
        @endif
        
        @if($link)
            <a href="{{ $link }}" class="inline-flex items-center text-indigo-600 font-medium hover:text-indigo-700 transition-colors duration-200">
                Read more
                <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                </svg>
            </a>
        @endif
    </div>
</div>
